module.exports = {
    extends: 'standard',
    rules: {
        indent: ['error', 4]
    }
}
