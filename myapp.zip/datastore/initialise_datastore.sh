#!/bin/bash

touch store.json
echo "{}" > store.json
touch metadata.json
echo "{}" > metadata.json
